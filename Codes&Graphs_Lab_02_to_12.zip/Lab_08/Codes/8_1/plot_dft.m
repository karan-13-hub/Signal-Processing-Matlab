%N has to be iven as input
%for p = 2:N-1
%calculating the fourier transform of the rectangular pulse
ti= -pi : (2*pi)/(N) : (pi-(2*pi/N));
%x = [ones(p,1);zeros(N-p,1)]; 
w = 2*pi;
x = abs(sin(ti*w));
X = directdft(x);
subplot(2,1,1)
stem(1:N,x);
title("Graph of input signal vs n");
xlabel(" n ");
ylabel("Magnitude of the input signal "); 
subplot(2,1,2);
stem(1:N,abs(X));
title("Graph of Discrete fourier transform of input signal vs n");
xlabel(" n ");
ylabel("Magnitude of the dft of input signal ");
%pause(2);
%end
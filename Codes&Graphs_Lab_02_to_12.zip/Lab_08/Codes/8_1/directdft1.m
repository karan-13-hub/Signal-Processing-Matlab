function X = directdft1(N,fre)
%calculating the discrete fourier transform of a function in O(N^2)
n= -pi:((2*pi)/N):pi;
x=sin(n*fre);
%N = length(x);
%length of the input signal 
F = zeros(N,N);
%N*N matrix
c = 0:N-1;
p = 0:N-1;
F = c'*p;
w = -1i*2*pi/N;
F = w.*F;
F = exp(F);
%calculating the discrete fourier transform matrix for N legnth input
%signal
X=F*x;
%calculating the dft of the input signal using the fourier transform matrix
subplot(2,1,1)
stem(1:N,x);
title("Graph of input signal vs n");
xlabel(" n ");
ylabel("Magnitude of the input signal "); 
subplot(2,1,2);
stem(1:N,abs(X));
title("Graph of Discrete fourier transform of input signal vs n");
xlabel(" n ");
ylabel("Magnitude of the dft of input signal ");
end
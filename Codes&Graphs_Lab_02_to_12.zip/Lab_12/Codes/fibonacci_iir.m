function [fib,b,a] = fibonacci_iir(n)
% Determine IIR filter that produces Fibonacci sequence
b = [1 0 0];
a = [1 -1 -1];
% Create length-n impulse to drive filter
imp = zeros(1,n);
imp(1) =1;
% Determine impulse response
fib = filter(b,a,imp);
stem(fib);
figure(2);
zplane(b,a);
end
%the fibonacci series filter is not stable because there is a pole outside
%the unit circle in z-plane 
function [b,a] = notch(w0,r)
% Compute denominator polynomial from r and w0
a = [1 -2*r*cos(w0) r*r];
% Compute numerator polynomial from w0
b = [1 -2*cos(w0) 1];
% Determine gain so that frequency response has magnitude 1 at w=0
b = b*abs((1+r*r-2*r*cos(w0))/(2-2*cos(w0)));
end
% H(z) = (z^2 - 2*cos(w0)*z + 1)/(z^2 - 2*r*cos(w0)*z + r*r);
n = 0:500;
w0 = pi/10;
[b,a] = notch(w0,0.80);
x = sin(w0*n) + sin(2*w0*n);
y =  filter(b,a,x);
figure(1);
freqz(b,a);
figure(2);
subplot(2,1,1)
plot(n,x);
subplot(2,1,2)
plot(n,y);
zplane(N,D);
%plotting function Z-plane for different values of coefficients of Numerator
%and denominator
title("Z-domain plot");
xlabel("Real part(z)");
ylabel("Imaginary part(z)");

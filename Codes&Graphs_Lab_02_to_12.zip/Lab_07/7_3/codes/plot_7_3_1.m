zplane([1 -5 6],[1 -2.5 1]);
%plotting function Z-plane for values of coefficients of Numerator
%and denominator of a frequency response
title("Z-domain plot");
xlabel("Real part(z)");
ylabel("Imaginary part(z)");
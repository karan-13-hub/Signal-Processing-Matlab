sound(y,fs); %play the sound of harmonic sinusoidal signa
plot(0:1/fs:duration,y);%plotting the Harmonic Sinusoidal Signal
title("Calculating the Signal using the Sinusoidal harmonics");
ylabel("y(t)")
xlabel("time")